/// @ref core
/// @file glm/packing.hpp

#include "detail/setup.hpp"

#pragma once

#include "detail/func_packing.hpp"
