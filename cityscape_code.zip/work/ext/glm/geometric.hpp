/// @ref core
/// @file glm/geometric.hpp

#include "detail/setup.hpp"

#pragma once

#include "detail/func_geometric.hpp"
